STOPWATCH 2.0

This software implements a simple lap stopwatch. The timings that are generated are then stored inside a file called the 
'timings.txt' file which is in the same file as the executable and the other zip files.

This application was written by Siddharth Kannan on Python 2.7 and Tkinter 8.5 on a machine running Windows XP SP 3.

This application is licensed under the WTFPL license. Please see the copying.txt file for more details.